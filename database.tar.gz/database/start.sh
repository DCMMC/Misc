#!/bin/bash 
python3 -m pipenv run python ./booom_db/manage.py runserver 0.0.0.0:8080 --insecure
