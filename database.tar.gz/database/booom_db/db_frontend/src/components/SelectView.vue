<template>
  <v-container justify-center>
    <v-layout
      row
    >
      <v-flex>
        <v-list two-line subheader>
            <v-subheader inset>管理</v-subheader>
            <v-list-tile
              v-for="item in items_manage"
              :key="item.title"
              avatar
              @click="goto(item)"
            >
              <v-list-tile-avatar>
                <v-icon :class="[item.iconClass]">{{ item.icon }}</v-icon>
              </v-list-tile-avatar>

              <v-list-tile-content>
                <v-list-tile-title>{{ item.title }}</v-list-tile-title>
                <v-list-tile-sub-title>{{ item.subtitle }}</v-list-tile-sub-title>
              </v-list-tile-content>

              <v-list-tile-action>
                <v-btn icon ripple>
                  <v-icon color="grey lighten-1">info</v-icon>
                </v-btn>
              </v-list-tile-action>
            </v-list-tile>

            <v-divider inset></v-divider>

            <v-subheader inset>查看</v-subheader>

            <v-list-tile
              v-for="item in items_view"
              :key="item.title"
              avatar
              @click="goto(item)"
            >
              <v-list-tile-avatar>
                <v-icon :class="[item.iconClass]">{{ item.icon }}</v-icon>
              </v-list-tile-avatar>

              <v-list-tile-content>
                <v-list-tile-title>{{ item.title }}</v-list-tile-title>
                <v-list-tile-sub-title>{{ item.subtitle }}</v-list-tile-sub-title>
              </v-list-tile-content>

              <v-list-tile-action>
                <v-btn icon ripple>
                  <v-icon color="grey lighten-1">info</v-icon>
                </v-btn>
              </v-list-tile-action>
            </v-list-tile>
        </v-list>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
  export default {
    data () {
      return {
        items_manage: [
          { icon: 'assignment', iconClass: 'blue white--text', title: '添加学员数据', subtitle: '新增学员信息',
            url: '/add-student.html' },
          { icon: 'call_to_action', iconClass: 'amber white--text', title: '添加教练数据', subtitle: '新增教练信息',
            url: '/add-coach.html' }
        ],
        items_view: [
          { icon: 'assignment', iconClass: 'blue white--text', title: '查看学员数据', subtitle: '查看并且修改教练数据',
            url: '/view-student.html' },
          { icon: 'call_to_action', iconClass: 'amber white--text', title: '查看教练数据', subtitle: '查看并且修改学员数据',
            url: '/view-coach.html' }
        ]
      }
    },
    methods: {
      goto(item) {
        window.location.href=item.url;
      }
    }
  }
</script>

<style>

</style>
