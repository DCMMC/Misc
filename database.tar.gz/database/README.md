# 一个简单的数据库前后端项目

## 超级用户

> 用于管理其他用户

* 账号: admin
* 密码: admin666

## 测试用户

> 用于登录

* 账号: 17775110118
* 密码: 97294597

## 依赖

* Python 3.7
* Pipenv
* MongoDB
* yarn(optional)

## 感谢

* Django
* MongoDB
* mongoengine
* vue
* yarn
* vuetify
* filepone
* python & pipenv

## 运行本项目

```bash
$ ./start.sh
```

## 修改

如果做了修改, 请执行 booom\_db/update\_run.sh
