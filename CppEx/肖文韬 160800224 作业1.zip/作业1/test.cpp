#include <iostream>

using namespace std;

int main()
{
    int a = 0, b = 0;
    int c = a + b;
    cout << "请输入a与b: " << endl;
    cin >> a >> b;
    cout << "a + b = " << (a + b) << endl;

    return 0;
}
